<?php
include 'shortlink.php';
$subdomain = $_GET['folder'];
$domain = $_SERVER['SERVER_NAME'];
$longURL = $domain . '/' . $subdomain;
$shortenedURL = shortenURL($longURL);
?>
    <!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" 
      content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0"/>
  <title>Setting Otomatis | ANTI CURL JS</title>
      <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700&family=Playfair+Display:wght@400;500;600;700&display=swap" rel="stylesheet">
  <style>
    @font-face {
      font-family: 'Poppins', sans-serif;;
      font-weight: bold;
      src: url('https://saweria.co/ibm-plex-mono-latin-400.woff');
    }
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Poppins', sans-serif;;
      font-weight: bold;
    }
    body {
      height: 100%;

      background: url('https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1920&q=80') no-repeat center center fixed;
      
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: flex-start; /* Align items to the top */
      padding: 40px 20px; /* Increased padding to push the content lower */
      height: 100vh; /* Full height of the viewport */
    }
    .gateway {
      background: rgba(0, 0, 0, 0.2);
      border: 4px solid rgba(0, 0, 0, 0.2);
      border-radius: 20px;
      padding: 20px;
      box-shadow: 8px 8px 0 rgba(0, 0, 0, 0.2);
      max-width: 500px;
      width: 90%;
      margin-top: 50px; /* Additional margin to push content down */
    }
    .source {
      background: #25D366;
      color: #000;
      font-weight: bold;
      padding: 6px 14px;
      border-radius: 8px;
      border: 2px solid #000;
      position: absolute;
      right: 20px;
      top: 20px;
      box-shadow: 4px 4px 0 #111;
    }
    label {
      display: block;
      margin-bottom: 15px;
      font-size: 16px;
    }
    input {
      width: 100%;
      padding: 10px;
      border: 2px solid #000;
      border-radius: 8px;
      background: rgba(0, 0, 0, 0.2);
      box-shadow: 4px 4px 0 #222;
      margin-top: 5px;
    }
    button {
      width: 100%;
      background: white;
      border: 2px solid #000;
      border-radius: 8px;
      padding: 10px;
      margin-top: 10px;
      font-size: 16px;
      box-shadow: 4px 4px 0 #222;
      cursor: pointer;
    }
    footer {
      margin-top: 30px;
      font-size: 14px;
    }
    footer a {
      text-decoration: none;
      color: blue;
      font-weight: bold;
      margin: 0 5px;
    }

    /* Toast notification */
    .toast {
      visibility: hidden;
      min-width: 250px;
      background-color: #4BB543;
      color: white;
      text-align: center;
      border-radius: 8px;
      padding: 16px;
      position: fixed;
      bottom: 30px;
      left: 50%;
      transform: translateX(-50%);
      z-index: 10000;
      font-size: 14px;
      box-shadow: 0.3rem 0.3rem 0 #222;
      transition: visibility 0s, opacity 0.5s ease-in-out;
      opacity: 0;
    }
    .toast.show {
      visibility: visible;
      opacity: 1;
    }
            /* Geser container sedikit ke bawah */
    .logo-container {
      display: flex;
      align-items: center;
      justify-content: center;
      transform: translateY(180px); /* turun 30px */
    }

/* Animasi naik turun + denyut */
    .logo-wrapper {
      animation: moveUpPulse 2s ease-in-out infinite alternate;
      display: inline-block;
    }

    .logo-img {
      width: 359px;
      height: auto;
      display: block;
    }

    @keyframes moveUpPulse {
      0% {
        transform: translateY(0) scale(1);
      }
      50% {
        transform: translateY(-15px) scale(1.08);
      }
      100% {
        transform: translateY(0) scale(1);
      }
    }
  </style>
</head>
<body>
<div class="logo-container">
    <div class="logo-wrapper">
      <img src="https://files.catbox.moe/91foho.png" alt="Yanz Logo" class="logo-img" />
    </div>
  </div>
<div class="gateway">

  <label>Link Nebar
    <input type="text" readonly value="https://<?= $domain ?>/<?= $subdomain ?>">
  </label>
  <label>Link Setting
    <input type="text" readonly value="https://<?= $domain ?>/<?= $subdomain ?>/update.php">
  </label>
  <label>Link Shortlink
    <input type="text" readonly value="<?= $shortenedURL ?>">
  </label>

  <button onclick="copyToClipboard()">Salin</button>
  <button onclick="bukaSetting()">Setting</button>
</div>

<div id="toast" class="toast">Link berhasil disalin!</div>


<script>
function showToast(message) {
  const toast = document.getElementById("toast");
  toast.textContent = message;
  toast.classList.add("show");
  setTimeout(() => {
    toast.classList.remove("show");
  }, 3000);
}

function copyToClipboard() {
  const url = "<?= $shortenedURL ?>";
  navigator.clipboard.writeText(url)
    .then(() => showToast("Link berhasil dibungkus, dan sudah berhasil disalin!"))
    .catch(() => showToast("Gagal menyalin link."));
}

function openLink() {
  window.location.href = "<?= $subdomain ?>";
}

function bukaSetting() {
  window.location.href = "<?= $subdomain ?>/update.php";
}
</script>

</body>
</html>
